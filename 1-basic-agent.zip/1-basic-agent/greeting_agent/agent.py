import pandas as pd
import re
from google.adk.agents import Agent
import os

# Configurable Excel file name
HSN_MASTER_FILE = r"C:\Users\skarthi\Downloads\agent-development-kit-crash-course-main\agent-development-kit-crash-course-main\1-basic-agent\greeting_agent\HSN_SAC.xlsx"

# data loading
hsn_df = pd.read_excel(HSN_MASTER_FILE)
hsn_dict = {str(c).strip(): d for c, d in zip(hsn_df.iloc[:, 0], hsn_df.iloc[:, 1])}

# Helper for hierarchical validation
def parent_codes_exist(code, hsn_dict):
    # Only for codes with length 8
    if len(code) != 8:
        return True, []
    parents = [code[:2], code[:4], code[:6]]
    missing = [p for p in parents if p not in hsn_dict]
    return len(missing) == 0, missing

def validate_hsn_codes(codes_input: str) -> dict:
    parts = re.split(r'[\s,;]+', codes_input.strip())
    codes = [p for p in parts if p]
    if not codes:
        return {"status": "error", "error_message": "No valid HSN code provided."}

    results = []
    any_success = False
    for code in codes:
        # Format validation
        if not code.isdigit() or len(code) not in (2, 4, 6, 8):
            results.append(f"HSN Code {code}: invalid format (must be numeric and 2, 4, 6, or 8 digits)")
            continue
        # Existence validation
        desc = hsn_dict.get(code)
        if desc:
            # Hierarchical validation for 8-digit codes
            if len(code) == 8:
                parents_ok, missing = parent_codes_exist(code, hsn_dict)
                if not parents_ok:
                    results.append(f"HSN Code {code}: valid, but missing parent codes: {', '.join(missing)}. Description: {desc}")
                    any_success = True
                    continue
            results.append(f"HSN Code {code}: valid. Description: {desc}")
            any_success = True
        else:
            results.append(f"HSN Code {code}: not found in master data")

    report = ". ".join(results)
    if not report.endswith("."):
        report += "."
    status = "success" if any_success else "error"
    return {"status": status, "report": report}

# Agent 
root_agent = Agent(
    name="hsn_validator_agent",
    model="gemini-2.0-flash",
    description="Agent for validating HSN code(s) from a provided master dataset.",
    instruction=(
        "You are an HSN Code Validation Agent.\n"
        "Ask the user to provide one or more HSN codes (comma, space, or semicolon separated).\n"
        "For each code, check if it is numeric and of valid length (2, 4, 6, or 8 digits).\n"
        "If valid, check if it exists in the master data and return its description.\n"
        "For 8-digit codes, also check if parent codes (first 2, 4, 6 digits) exist.\n"
        "If a code is invalid or not found, explain why.\n"
        "Respond in a clear, conversational manner."
    ),
    tools=[validate_hsn_codes]
) 